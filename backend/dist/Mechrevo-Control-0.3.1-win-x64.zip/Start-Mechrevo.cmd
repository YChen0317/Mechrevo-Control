@echo off
start "" "%ProgramFiles%\dotnet\dotnet.exe" "%~dp0MechrevoControl.Frontend.dll"
